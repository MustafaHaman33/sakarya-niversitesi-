let images = [ "https://upload.wikimedia.org/wikipedia/commons/8/83/Ulucami%2C_Tarsus%2C_Mersin_Province.jpg",
"https://static.wixstatic.com/media/36dc4f_1f2aef16e42e46fea70db28652df2d8c~mv2_d_5520_4140_s_4_2.jpg/v1/fill/w_1480,h_1110,al_c,q_85,usm_0.66_1.00_0.01,enc_auto/36dc4f_1f2aef16e42e46fea70db28652df2d8c~mv2_d_5520_4140_s_4_2.jpg",
                "https://gezilmesigerekenyerler.com/wp-content/uploads/2015/01/Tarsus-Selalesi-Mersin-1.jpg",
                "https://www.evrensel.net/images/840/upload/dosya/79096.jpg", 
                "https://www.kulturportali.gov.tr/contents/images/25022013_342b14b7-67e1-4e35-9a2d-d1193ae9bc08.jpg",
                "https://gezicini.com/wp-content/uploads/2021/12/tarsuslu.jpg",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRxJWFL1RqZ6SeMc5WkpMa3tWINofPSqeuUag&usqp=CAU"];
let currentImageIndex = 2; // Başlangıçta ortada 3. resim olduğu için

document.getElementById("next").addEventListener("click", function() {
    currentImageIndex = (currentImageIndex + 1) % images.length;
    document.getElementById("img1").src = images[(currentImageIndex - 1 + images.length) % images.length];
    document.getElementById("img2").src = images[currentImageIndex];
    document.getElementById("img3").src = images[(currentImageIndex + 1) % images.length];
});

document.getElementById("prev").addEventListener("click", function() {
    currentImageIndex = (currentImageIndex - 1 + images.length) % images.length;
    document.getElementById("img1").src = images[(currentImageIndex - 1 + images.length) % images.length];
    document.getElementById("img2").src = images[currentImageIndex];
    document.getElementById("img3").src = images[(currentImageIndex + 1) % images.length];
});

let currentIndex = 0;
const imageds = document.querySelectorAll('.footer-section img');

function showNextImage() {
  imageds[currentIndex].classList.remove('main');
  currentIndex++;
  if (currentIndex >= imageds.length) {
    currentIndex = 0;
  }
  imageds[currentIndex].classList.add('main');
}

document.getElementById('next').addEventListener('click', showNextImage);
