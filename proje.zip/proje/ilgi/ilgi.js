var interestsContainer = document.getElementById('interests-container');

var interestsData = [
  {
    title: 'The Mother',
    description: 'En sevdiğim filmler',
    image: 'https://occ-0-3889-358.1.nflxso.net/dnm/api/v6/6gmvu2hxdfnQ55LZZjyzYR4kzGk/AAAABWR2lqILHTgyWUcOS7d8i_973mtiTCuqWWQctdM-TVfuMoOCmyojO2k81rBW_-XQdjoDMJG9uigVIFdfKh6Fm50FYVjPmwT1-Eovwqw0EXUYhvIcDru9s3VcGwezliac18N56RQXfvwk1qpBZur66aaEnzyVU_9kkg0YhMA3JKsB5UqqVz7ycUhedMsaZWM.jpg',
    url: 'https://tr.flixable.com/title/the-mother/'
  },
  {
    title: 'FENERBAHCE',
    description: 'Favori spor dallarım',
    image: 'https://media.fenerbahce.org/FB/media/FB/Images/Logo/logo.png?ext=.png',
    url: 'https://www.fenerbahce.org/'
  }
];

function createOnClick(url) {
  return function() {
    window.location.href = url;
  };
}

function renderInterests() {
  interestsContainer.innerHTML = '';

  for (var i = 0; i < interestsData.length; i++) {
    var interest = interestsData[i];

    var interestCard = document.createElement('div');
    interestCard.classList.add('interest-card');

    interestCard.onclick = createOnClick(interest.url);

    var interestImage = document.createElement('img');
    interestImage.classList.add('interest-image');
    interestImage.src = interest.image;

    var interestTitle = document.createElement('h2');
    interestTitle.classList.add('interest-title');
    interestTitle.textContent = interest.title;

    var interestDescription = document.createElement('p');
    interestDescription.classList.add('interest-description');
    interestDescription.textContent = interest.description;

    interestCard.appendChild(interestImage);
    interestCard.appendChild(interestTitle);
    interestCard.appendChild(interestDescription);

    interestsContainer.appendChild(interestCard);
  }
}

renderInterests();
