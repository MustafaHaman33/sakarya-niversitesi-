<?php // Örnek bir dizide kullanıcı adı ve şifre doğruluğunu kontrol eder. // Gerçek bir uygulamada, bu bilgiler genellikle veritabanında saklanır. $users = array( "b1812100001@sakarya.edu.tr" => "b1812100001" );
$users = array( "g211210570@sakarya.edu.tr" => "g211210570" );
$username = $_POST['username']; $password = $_POST['password'];




if(!isset($users[$username]))
{
    header('Location: login.html'); exit(); 
}


if($users[$username]!=$password)
{   
    header('Location: login.html'); exit();
}

 echo "<spam style=\"text-align: center;\">Hoşgeldiniz<spam style=\"font-size:20px ;\">"." "."{$password}</spam></spam>" ; 
 ?>