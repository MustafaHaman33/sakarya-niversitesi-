new Vue({
    el: '#app',
    data: {
      form: {
        name: '',
        email: '',
        message: ''
      }
    },
    methods: {
      clearForm() {
        this.form.name = '';
        this.form.email = '';
        this.form.message = '';
      },
      submitForm() {
        if(this.validateForm()) {
          // Burada formunuzu sunucuya gönderme kodunu ekleyebilirsiniz.
          console.log(this.form);
          this.clearForm();
        }
      },
      validateForm() {
        // Burada e-posta ve diğer alanları doğrulayabilirsiniz.
        // Şimdilik sadece basit bir doğrulama yapalım.
        return this.form.name !== '' && this.form.email.includes('@') && this.form.message !== '';
      }
    }
  });
  