// Öğeyi seçme
let h1 = document.querySelector('h1');

// Düğmeye tıklama olayını ekler
document.querySelector('button').addEventListener('click', function() {
    h1.style.color = 'red';
});
// Tıklama olayını dinleme
button.addEventListener('click', function() {
    console.log('Düğmeye tıklandı!');
});
// Yeni bir AJAX isteği oluşturma
let xhr = new XMLHttpRequest();
xhr.open('GET', 'https://api.example.com/data', true);
xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
        let data = JSON.parse(xhr.responseText);
        console.log(data);
    }
}
xhr.send();
